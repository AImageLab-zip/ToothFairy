from nnunetv2.training.nnUNetTrainer.variants.network_architecture.nnUNetTrainer_NexToU_Hierarchical_BTI_ToothFairy48 import nnUNetTrainer_NexToU_Hierarchical_BTI_ToothFairy48

class nnUNetTrainer_NexToU_Hierarchical_BTI_ToothFairy48_NoMirroring(nnUNetTrainer_NexToU_Hierarchical_BTI_ToothFairy48):
    def configure_rotation_dummyDA_mirroring_and_inital_patch_size(self):
        rotation_for_DA, do_dummy_2d_data_aug, initial_patch_size, mirror_axes = \
            super().configure_rotation_dummyDA_mirroring_and_inital_patch_size()
        mirror_axes = None
        self.inference_allowed_mirroring_axes = None
        return rotation_for_DA, do_dummy_2d_data_aug, initial_patch_size, mirror_axes
        

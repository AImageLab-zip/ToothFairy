from torch import nn

class DeepSupervisionWrapper(nn.Module):
    def __init__(self, loss_list, weight_factors=None):

        super(DeepSupervisionWrapper, self).__init__()
        self.weight_factors = weight_factors
        self.loss_list = loss_list

        if len(self.loss_list) != len(self.weight_factors):
            raise ValueError("length of loss_list and weight_factors must be equal")

    def forward(self, output, target, current_epoch):
        args = [output, target]
        if self.weight_factors is None:
            weights = [1] * len(args[0])
        else:
            weights = self.weight_factors

        # we initialize the loss like this instead of 0 to ensure it sits on the correct device, not sure if that's
        # really necessary
        raw_l = self.loss_list[0](*[j[0] for j in args], current_epoch)
        l = weights[0] * raw_l
        for i, inputs in enumerate(zip(*args)):
            if i == 0:
                continue
            raw_l = self.loss_list[i](*inputs, current_epoch)
            l += weights[i] * raw_l

        return l